<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quem Somos</title>
    <link rel="stylesheet" href="css/quem-somos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="Index.php">CODE-JR</a></div>
            <!-- Botão com três linhas -->
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
            </ul>
        </nav>
    </header>

    <div class="quem-somos">
        <h1>Quem somos</h1>
        <p>
            Somos a Code.Jr, uma plataforma inovadora criada para transformar o aprendizado em lógica de programação em
            uma experiência divertida, acessível e interativa. Nosso objetivo é inspirar jovens mentes a explorarem o
            universo da tecnologia de forma lúdica, utilizando jogos e tutoriais interativos que tornam o aprendizado
            leve e estimulante.
        </p>
    </div>
    <script src="script.js"></script>
</body>

</html>
<?php
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code-Jr</title>
    <link rel="stylesheet" href="css/jogos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="Index.php">CODE-JR</a></div>
            <!-- Botão com três linhas -->
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
            </ul>
        </nav>
    </header>

    <main class="games-container">
        <div class="game">
            <a href="jogo.php">
                <img src="imagens-code-jr/modocampanha.png" alt="Modo Campanha" class="modo-campanha" />
            </a>
        </div>
        <div class="game">
            <a href="jogO.php">
                <img src="imagens-code-jr/modocompetitivo.png" alt="Modo Competitivo" class="modo-competitivo" />
            </a>
        </div>
<script src="script.js"></script>
    </main>
</body>

</html>
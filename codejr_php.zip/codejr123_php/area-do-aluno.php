<?php
session_start();
include_once('conexao.php');

// Verificar se o usuário está logado
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

// Buscar dados do usuário logado com JOIN para trazer curso e status
$id = $_SESSION['id'];

$sql = "SELECT 
            u.nome,
            u.email,
            u.foto_perfil,
            c.nome AS curso,
            s.nome AS status
        FROM usuarios u
        LEFT JOIN cursos c ON u.curso_id = c.id
        LEFT JOIN status s ON u.status_id = s.id
        WHERE u.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "Usuário não encontrado.";
    exit();
}

// Se o usuário não tiver foto, usa uma imagem padrão
$foto = !empty($user['foto_perfil']) ? 'uploads/' . $user['foto_perfil'] : 'uploads/default.png';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Área do Aluno</title>
    <link rel="stylesheet" href="css/area-do-aluno.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="index.php">CODE-JR</a></div>
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="area-do-aluno.php">Área do Aluno</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <section class="profile-card">
            <img src="<?php echo htmlspecialchars($foto); ?>" alt="Foto do Aluno" class="profile-img" />
            <h2 class="student-name"><?php echo htmlspecialchars($user['nome']); ?></h2>
            <p class="student-role">Aluno - Desenvolvimento Web</p>

            <div class="info-box">
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Curso:</strong> <?php echo htmlspecialchars($user['curso'] ?? 'Não informado'); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($user['status'] ?? 'Não informado'); ?></p>
            </div>
            <form action="editar-perfil.php" method="get">
                <button type="submit" class="edit-btn">Editar Perfil</button>
            </form>

        </section>
    </main>

    <script src="script.js"></script>
</body>

</html>
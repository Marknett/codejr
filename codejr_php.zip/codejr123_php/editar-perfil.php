<?php
session_start();
include_once('conexao.php');

// Verificar login
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

$id = $_SESSION['id'];

// Buscar dados atuais do usuário
$sql = "SELECT nome, email, foto_perfil FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Processar formulário
if (isset($_POST['submit'])) {
    $novo_nome = $_POST['nome'];

    // Processar foto
    $foto = $_FILES['foto'];
    $pasta = 'uploads/';
    $foto_atual = $user['foto_perfil'];

    if ($foto['error'] == 0) {
        $extensao = strtolower(pathinfo($foto['name'], PATHINFO_EXTENSION));
        $permitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($extensao, $permitidos)) {
            $nome_foto = uniqid() . "." . $extensao;
            move_uploaded_file($foto['tmp_name'], $pasta . $nome_foto);

            // Deleta foto antiga, se não for a padrão
            if ($foto_atual != 'default.png' && file_exists($pasta . $foto_atual)) {
                unlink($pasta . $foto_atual);
            }
        } else {
            echo "<script>alert('Formato de imagem inválido!');</script>";
            $nome_foto = $foto_atual;
        }
    } else {
        // Se não enviou nova foto, mantém a antiga
        $nome_foto = $foto_atual;
    }

    // Atualizar no banco
    $sqlUpdate = "UPDATE usuarios SET nome = ?, foto_perfil = ? WHERE id = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param("ssi", $novo_nome, $nome_foto, $id);

    if ($stmtUpdate->execute()) {
        echo "<script>alert('Dados atualizados com sucesso!'); window.location='area-do-aluno.php';</script>";
    } else {
        echo "Erro ao atualizar: " . $stmtUpdate->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="css/editar-perfil.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="index.php">CODE-JR</a></div>
            <ul class="nav-links">
                <li><a href="area-do-aluno.php">Área do Aluno</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main class="edit-profile-container">
        <h2>Editar Perfil</h2>
        <form method="POST" enctype="multipart/form-data">
            <label>Nome:</label>
            <input type="text" name="nome" value="<?php echo htmlspecialchars($user['nome']); ?>" required>

            <label>Email:</label>
            <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>

            <label>Foto de Perfil:</label>
            <input type="file" name="foto" accept="image/*">
            <br>
            <img src="uploads/<?php echo htmlspecialchars($user['foto_perfil']); ?>" alt="Foto Atual" width="150" style="border-radius: 8px; margin-top: 10px;">

            <br><br>
            <button type="submit" name="submit" class="btn">Salvar Alterações</button>
        </form>
    </main>
</body>
</html>

-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS codejr;
USE codejr;

-- Tabela de Cursos
CREATE TABLE IF NOT EXISTS cursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Inserir cursos básicos
INSERT INTO cursos (nome) VALUES 
('Front-End Iniciante'),
('Back-End Intermediário'),
('Desenvolvimento FullStack'),
('Banco de Dados Avançado');

-- Tabela de Status
CREATE TABLE IF NOT EXISTS status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

-- Inserir status básicos
INSERT INTO status (nome) VALUES 
('Ativo'),
('Inativo'),
('Pendente');

-- Tabela de Usuários atualizada
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    curso_id INT,
    status_id INT,
    foto_perfil VARCHAR(255) DEFAULT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (status_id) REFERENCES status(id) ON DELETE SET NULL ON UPDATE CASCADE
);

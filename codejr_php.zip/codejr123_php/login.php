<?php
session_start();
include_once('conexao.php');

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verificar se os campos foram preenchidos
    if (empty($email) || empty($senha)) {
        echo "Preencha todos os campos!";
        exit;
    }

    // Preparar a consulta para evitar SQL Injection
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificar se encontrou o usuário
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verificar se a senha está correta
        if (password_verify($senha, $user['senha'])) {
            $_SESSION['id'] = $user['id'];
            $_SESSION['nome'] = $user['nome'];
            header('Location: area-do-aluno.php');
            exit;
        } else {
            echo "Senha incorreta!";
        }
    } else {
        echo "Usuário não encontrado!";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
     <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="Index.php">CODE-JR</a></div>
            <!-- Botão com três linhas -->
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
            </ul>
        </nav>
    </header>
     <main class="login-container">
        <h2>Login</h2>
      <form id="login-form" method="POST">
    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required>

    <label for="senha">Senha:</label>
    <input type="password" id="senha" name="senha" required>

<form action="area-do-aluno.php" method="post">
  <button class="btn" type="submit" name="submit">Entrar</button>
</form>


</form>

    </main>
    <script src="script.js"></script>
</body>
</html>
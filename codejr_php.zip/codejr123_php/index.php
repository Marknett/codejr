<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code-Jr</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="#">CODE-JR</a></div>
            <!-- Botão com três linhas -->
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
            </ul>
        </nav>
    </header>
     <main>
        <div class="jogar-button" id="jogarButton">
            <h1><a href="jogos.php">Jogar</a></h1>
        </div>
    </main>
    <script src="script.js"></script>
   
</body>

</html>
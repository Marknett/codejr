<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "codejr";
$porta = 3306; // Altere se necessário

$conn = new mysqli($servidor, $usuario, $senha, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
<?php
include_once('conexao.php');

if (isset($_POST['submit'])) {

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $confirmar_senha = $_POST['confirmar-senha'];
    $curso_id = $_POST['curso'];
    $status_id = 1; // Ativo por padrão

    // Processar upload da imagem
    $imagem = $_FILES['foto'];
    $pasta = 'uploads/';

    // Verificar se tem imagem
    if ($imagem['error'] == 0) {
        $extensao = strtolower(pathinfo($imagem['name'], PATHINFO_EXTENSION));

        // Verificar se é uma imagem válida
        $formatosPermitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($extensao, $formatosPermitidos)) {
            $nomeImagem = uniqid() . "." . $extensao;
            move_uploaded_file($imagem['tmp_name'], $pasta . $nomeImagem);
        } else {
            echo "<script>alert('Formato de imagem inválido. Use jpg, jpeg, png, gif ou webp.');</script>";
            $nomeImagem = 'uploads/default.png';
        }
    } else {
        $nomeImagem = 'uploads/default.png';
    }

    // Verificar senha
    if ($senha != $confirmar_senha) {
        echo "<script>alert('As senhas não coincidem!');</script>";
    } else {
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, curso_id, status_id, foto_perfil) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssiss", $nome, $email, $senha_hash, $curso_id, $status_id, $nomeImagem);

        if ($stmt->execute()) {
            header('Location: login.php');
            exit();
        } else {
            echo "Erro ao cadastrar: " . $stmt->error;
        }

        $stmt->close();
    }
}

$cursos = $conn->query("SELECT id, nome FROM cursos");
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscreva-se</title>
    <link rel="stylesheet" href="css/inscreva-se.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logo"><a href="index.php">CODE-JR</a></div>
            <button class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </button>
            <ul class="nav-links" id="nav-links">
                <li><a href="quem-somos.php">Quem Somos</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="inscreva-se.php">Inscreva-se</a></li>
            </ul>
        </nav>
    </header>

   <main class="cadastro-container">
    <h2>Inscreva-se</h2>
    <form id="cadastro-form" method="POST" enctype="multipart/form-data">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required>

        <label for="curso">Selecione seu curso:</label>
        <select name="curso" id="curso" required>
            <option value="">Selecione...</option>
            <?php while($curso = $cursos->fetch_assoc()): ?>
                <option value="<?php echo $curso['id']; ?>"><?php echo htmlspecialchars($curso['nome']); ?></option>
            <?php endwhile; ?>
        </select>

        <label for="foto">Foto de Perfil:</label>
        <input type="file" id="foto" name="foto" accept="image/*">

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required>

        <label for="confirmar-senha">Confirmar Senha:</label>
        <input type="password" id="confirmar-senha" name="confirmar-senha" required>

        <button name="submit" class="btn" type="submit">Cadastrar</button>
    </form>
</main>

    <script src="script.js"></script>
</body>

</html>

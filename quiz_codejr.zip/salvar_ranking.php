<?php
include 'db/conexao.php';

$nome = $_POST['nome'];
$pontos = $_POST['pontos'];

$sql = "INSERT INTO ranking_jogo (nome, pontos) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $nome, $pontos);

if ($stmt->execute()) {
    echo "Ranking salvo!";
} else {
    echo "Erro ao salvar: " . $stmt->error;
}
?>
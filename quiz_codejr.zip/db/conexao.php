<?php
$host = 'localhost';
$user = 'root';
$senha = '';
$banco = 'codejr';

$conn = new mysqli($host, $user, $senha, $banco);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
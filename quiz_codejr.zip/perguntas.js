const perguntas = {
    facil: [
        {
            pergunta: "Qual estrutura representa uma decisão em programação?",
            alternativas: ["a) if", "b) for", "c) while", "d) switch"],
            correta: "a"
        },
        {
            pergunta: "O que é uma variável?",
            alternativas: ["a) Um comando", "b) Um laço", "c) Um espaço para armazenar valores", "d) Um erro"],
            correta: "c"
        }
    ],
    medio: [
        {
            pergunta: "Qual é o valor de x após: x = 2 + 3 * 4?",
            alternativas: ["a) 14", "b) 20", "c) 24", "d) 9"],
            correta: "a"
        }
    ],
    dificil: [
        {
            pergunta: "Qual a saída de: if(true && false || true)?",
            alternativas: ["a) false", "b) true", "c) null", "d) erro"],
            correta: "b"
        }
    ]
};
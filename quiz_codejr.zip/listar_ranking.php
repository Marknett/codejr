<?php
include 'db/conexao.php';

$sql = "SELECT nome, pontos, data_registro FROM ranking_jogo ORDER BY pontos DESC, data_registro ASC LIMIT 10";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    echo "<p><strong>{$row['nome']}</strong> - {$row['pontos']} pontos em {$row['data_registro']}</p>";
}
?>
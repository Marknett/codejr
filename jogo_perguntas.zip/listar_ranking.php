<?php
include 'db/conexao.php';

$sql = "SELECT nome, pontos FROM ranking ORDER BY pontos DESC LIMIT 10";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    echo "<p>{$row['nome']} - {$row['pontos']} pontos</p>";
}
?>
<?php
$host = 'localhost';
$user = 'root';
$senha = '';
$banco = 'jogo_logica';

$conn = new mysqli($host, $user, $senha, $banco);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Jogo de Lógica</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Quiz de Lógica de Programação</h1>

    <div id="selecaoDificuldade">
        <h2>Escolha a Dificuldade</h2>
        <button onclick="iniciar('facil')">Fácil</button>
        <button onclick="iniciar('medio')">Média</button>
        <button onclick="iniciar('dificil')">Difícil</button>
    </div>

    <div id="quiz" style="display:none;">
        <div id="timer">Tempo: 60s</div>
        <h2 id="pergunta"></h2>
        <div id="alternativas"></div>
        <p id="feedback"></p>
    </div>

    <div id="fim" style="display:none;">
        <h2>Fim do jogo!</h2>
        <p id="pontuacaoFinal"></p>
        <input type="text" id="nome" placeholder="Digite seu nome">
        <button onclick="salvarRanking()">Salvar Ranking</button>
        <div id="ranking"></div>
    </div>
</div>

<script src="perguntas.js"></script>
<script>
let dificuldade = '';
let perguntasSelecionadas = [];
let indice = 0;
let pontuacao = 0;
let tempo = 60;
let timer;

function iniciar(dif) {
    dificuldade = dif;
    perguntasSelecionadas = perguntas[dif].sort(() => 0.5 - Math.random()).slice(0, 5);
    document.getElementById('selecaoDificuldade').style.display = 'none';
    document.getElementById('quiz').style.display = 'block';
    proximaPergunta();
}

function proximaPergunta() {
    if (indice >= perguntasSelecionadas.length) {
        finalizar();
        return;
    }

    const atual = perguntasSelecionadas[indice];
    document.getElementById('pergunta').innerText = atual.pergunta;
    const alternativasHTML = atual.alternativas.map((alt, i) => 
        `<button onclick="responder('${['a','b','c','d'][i]}')">${alt}</button>`
    ).join('');
    document.getElementById('alternativas').innerHTML = alternativasHTML;
    document.getElementById('feedback').innerText = '';

    tempo = 60;
    document.getElementById('timer').innerText = `Tempo: ${tempo}s`;
    clearInterval(timer);
    timer = setInterval(() => {
        tempo--;
        document.getElementById('timer').innerText = `Tempo: ${tempo}s`;
        if (tempo <= 0) {
            clearInterval(timer);
            indice++;
            proximaPergunta();
        }
    }, 1000);
}

function responder(resposta) {
    const correta = perguntasSelecionadas[indice].correta;
    if (resposta === correta) {
        pontuacao += 20;
        document.getElementById('feedback').innerText = 'Correto!';
    } else {
        document.getElementById('feedback').innerText = 'Errado!';
    }
    clearInterval(timer);
    setTimeout(() => {
        indice++;
        proximaPergunta();
    }, 1000);
}

function finalizar() {
    document.getElementById('quiz').style.display = 'none';
    document.getElementById('fim').style.display = 'block';
    document.getElementById('pontuacaoFinal').innerText = `Sua pontuação foi: ${pontuacao}`;
    carregarRanking();
}

function salvarRanking() {
    const nome = document.getElementById('nome').value;
    fetch('salvar_ranking.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `nome=${encodeURIComponent(nome)}&pontos=${pontuacao}`
    }).then(() => carregarRanking());
}

function carregarRanking() {
    fetch('listar_ranking.php')
        .then(res => res.text())
        .then(data => {
            document.getElementById('ranking').innerHTML = `<h3>Ranking:</h3>${data}`;
        });
}
</script>
</body>
</html>

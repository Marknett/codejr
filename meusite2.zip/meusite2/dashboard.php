<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('Location: index.php');
    exit();
}
$tipo = $_SESSION['tipo_usuario'];
echo "<h2>Bem-vindo, " . $_SESSION['nome'] . "</h2>";

if ($tipo == 4) {
    echo "<a href='cadastro.php'>Cadastrar Usuário</a><br>";
    echo "<a href='visualizar.php'>Ver Tarefas</a><br>";
    echo "<a href='historico.php'>Ver Histórico</a><br>";
}
if ($tipo == 1) {
    echo "<a href='criar_bloco.php'>Criar Blocos</a><br>";
    echo "<a href='visualizar.php'>Ver Tarefas</a><br>";
    echo "<a href='historico.php'>Ver Histórico</a><br>";
}
if ($tipo == 2 || $tipo == 3) {
    echo "<a href='visualizar.php'>Ver Tarefas</a><br>";
}
echo "<a href='logout.php'>Sair</a>";
?>

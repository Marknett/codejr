<?php
session_start();
include('db/conexao.php');

if (!isset($_SESSION['id']) || $_SESSION['tipo_usuario'] != 4) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $tipo = $_POST['tipo_usuario'];

    $sql = "INSERT INTO usuarios (nome, email, senha, tipo_usuario) 
            VALUES ('$nome', '$email', '$senha', '$tipo')";

    if (mysqli_query($conn, $sql)) {
        echo "Cadastro realizado!";
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>
<a href="dashboard.php">Voltar</a> | <a href="logout.php">Sair</a>
<h2>Cadastrar Usuário</h2>
<form method="POST">
    Nome: <input type="text" name="nome" required><br>
    Email: <input type="email" name="email" required><br>
    Senha: <input type="password" name="senha" required><br>
    Tipo:
    <select name="tipo_usuario">
        <option value="1">Criador</option>
        <option value="2">Supervisor</option>
        <option value="3">Executor</option>
        <option value="4">Suporte</option>
    </select><br>
    <input type="submit" value="Cadastrar">
</form>

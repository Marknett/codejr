<?php
session_start();
include('db/conexao.php');

if (!isset($_SESSION['id'])) {
    header('Location: index.php');
    exit();
}

$tipo = $_SESSION['tipo_usuario'];

if ($tipo == 3) {
    $query = "SELECT * FROM blocos WHERE status != 'Concluido' AND finalizado = 0";
} elseif ($tipo == 1 || $tipo == 2) {
    $query = "SELECT * FROM blocos WHERE finalizado = 0";
} elseif ($tipo == 4) {
    $query = "SELECT * FROM blocos";
}

$blocos = mysqli_query($conn, $query);
?>
<a href="dashboard.php">Voltar</a> | <a href="logout.php">Sair</a>
<h2>Lista de Blocos</h2>
<?php while ($bloco = mysqli_fetch_assoc($blocos)): ?>
    <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
        <h3><?= htmlspecialchars($bloco['titulo']) ?></h3>
        <p><?= nl2br(htmlspecialchars($bloco['conteudo'])) ?></p>
        <p>Status: <strong><?= $bloco['status'] ?></strong></p>
        <p>Finalizado: <strong><?= $bloco['finalizado'] ? 'Sim' : 'Não' ?></strong></p>

        <?php if ($tipo == 3 && $bloco['status'] != 'Concluido' && !$bloco['finalizado']): ?>
            <form method="POST" action="atualizar_status.php">
                <input type="hidden" name="id" value="<?= $bloco['id'] ?>">
                <select name="status">
                    <option value="Realizando" <?= $bloco['status'] == 'Realizando' ? 'selected' : '' ?>>Realizando Tarefa</option>
                    <option value="Concluido">Tarefa Concluída</option>
                </select>
                <input type="submit" value="Atualizar Status">
            </form>
        <?php endif; ?>

        <?php if ($tipo == 1 && $bloco['status'] == 'Concluido' && !$bloco['finalizado']): ?>
            <form method="POST" action="finalizar_bloco.php">
                <input type="hidden" name="id" value="<?= $bloco['id'] ?>">
                <input type="submit" value="Dar OK e Finalizar">
            </form>
        <?php endif; ?>
    </div>
<?php endwhile; ?>

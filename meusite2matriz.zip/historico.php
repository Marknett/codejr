<?php
session_start();
include('db/conexao.php');

if (!isset($_SESSION['id']) || ($_SESSION['tipo_usuario'] != 1 && $_SESSION['tipo_usuario'] != 4)) {
    header('Location: dashboard.php');
    exit();
}

$blocos = mysqli_query($conn, "SELECT * FROM blocos WHERE finalizado = 1");
?>
<a href="dashboard.php">Voltar</a> | <a href="logout.php">Sair</a>
<h2>Histórico de Blocos Finalizados</h2>
<?php while ($bloco = mysqli_fetch_assoc($blocos)): ?>
    <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
        <h3><?= htmlspecialchars($bloco['titulo']) ?></h3>
        <p><?= nl2br(htmlspecialchars($bloco['conteudo'])) ?></p>
        <p>Status final: <strong><?= $bloco['status'] ?></strong></p>
        <p>Data de Criação: <?= $bloco['data_criacao'] ?></p>
    </div>
<?php endwhile; ?>

<?php
session_start();
include('db/conexao.php');

if ($_SESSION['tipo_usuario'] != 1) {
    header('Location: dashboard.php');
    exit();
}

$id = $_POST['id'];
mysqli_query($conn, "UPDATE blocos SET finalizado = 1 WHERE id = $id");

header('Location: visualizar.php');
?>

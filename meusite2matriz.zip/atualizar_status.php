<?php
session_start();
include('db/conexao.php');

if ($_SESSION['tipo_usuario'] != 3) {
    header('Location: dashboard.php');
    exit();
}

$id = $_POST['id'];
$status = $_POST['status'];

mysqli_query($conn, "UPDATE blocos SET status='$status' WHERE id=$id");

header('Location: visualizar.php');
?>

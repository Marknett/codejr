<?php
session_start();
include('db/conexao.php');

if ($_SESSION['tipo_usuario'] != 1) {
    header('Location: dashboard.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST['titulo'];
    $conteudo = $_POST['conteudo'];
    $sql = "INSERT INTO blocos (titulo, conteudo, status, finalizado, data_criacao) 
            VALUES ('$titulo', '$conteudo', 'Novo', 0, NOW())";

    if (mysqli_query($conn, $sql)) {
        echo "Bloco criado com sucesso!";
    } else {
        echo "Erro: " . mysqli_error($conn);
    }
}
?>
<a href="dashboard.php">Voltar</a> | <a href="logout.php">Sair</a>
<h2>Criar Bloco</h2>
<form method="POST">
    Título: <input type="text" name="titulo" required><br>
    Conteúdo:<br>
    <textarea name="conteudo" rows="5" cols="50" required></textarea><br>
    <input type="submit" value="Criar">
</form>
